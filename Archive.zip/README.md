## About
A start up framework based on laravel.Common functionalities that maximum projects require will be there.

## Version
# Laravel : 8.12