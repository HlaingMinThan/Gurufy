<style>
    .logo{
        font-size: 32px;
        border-top:1px solid #AECE61;
        /* background-color: #AECE61; */
    }
    .logo span.head{
        /* background-color: #FFF; */
        font-weight: 600;
        font-size: 100%;
        color: #AECE61;
        /* padding: 0 5px; */
    }
    .logo span.sub{
        font-weight: 300;
        font-size: 100%;
        color: white;
        text-transform: uppercase;        
        /* padding: 0 5px; */
    }
</style>
<span class="logo">
    <span class="head">Y</span><span class="sub">asshas</span>
</span>