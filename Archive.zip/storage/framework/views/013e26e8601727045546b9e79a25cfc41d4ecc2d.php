<style type="text/css">
    .top-message{
        display: block;
    }
</style>

<?php if(session('message')): ?>
<div class="top-message text-center alert bg-primary text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-info"></i> 
    <?php echo e(session('message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('secondary_message')): ?>
<div class="top-message text-center alert bg-secondary text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-info"></i> 
    <?php echo e(session('secondary_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('success_message')): ?>
<div class="top-message text-center alert bg-success text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="far fa-check-square"></i> 
    <?php echo e(session('success_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('error_message')): ?>
<div class="top-message text-center alert bg-danger text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-exclamation-triangle"></i> 
    <?php echo e(session('error_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('warning_message')): ?>
<div class="top-message text-center alert bg-warning text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-exclamation-triangle"></i> 
    <?php echo e(session('warning_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('info_message')): ?>
<div class="top-message text-center alert bg-info text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-info"></i> 
    <?php echo e(session('info_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('light_message')): ?>
<div class="top-message text-center alert bg-light text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-info"></i> 
    <?php echo e(session('light_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>
<?php if(session('dark_message')): ?>
<div class="top-message text-center alert bg-dark text-white alert-dismissible alert-message fade show" role="alert" id="top-message">
    <i class="fas fa-info"></i> 
    <?php echo e(session('dark_message')); ?>

    <i class="fas fa-times float-end cursor-pointer" data-bs-dismiss="alert"></i>
</div>
<?php endif; ?>



<script type="text/javascript">
	setTimeout(function(){
		// document.getElementById("top-message").remove();
	}, 5000);
</script><?php /**PATH /opt/homebrew/var/www/gurufy/resources/views/includes/top_message.blade.php ENDPATH**/ ?>