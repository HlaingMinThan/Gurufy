<?php $__env->startSection('title'); ?>
<?php echo e(!empty($title)?$title:env('APP_NAME')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_css'); ?>
    <?php echo $__env->yieldContent('custom_css'); ?>
    <style type="text/css">
        .top_message{
            position: absolute;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<nav id="sidebar" class="sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="<?php echo e(route('admin-dashboard')); ?>">
            <span class="align-middle"><?php echo e(env('APP_NAME')); ?> Admin</span>
        </a>

        <ul class="sidebar-nav">
            <li class="sidebar-header">
                Admin
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin-dashboard')); ?>">
                    <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                </a>
            </li>


            <!-- <li class="sidebar-header">
                Management
            </li> -->
            

            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin-standard-list')); ?>">
                    <i class="fas fa-graduation-cap"></i> <span class="align-middle">Standard</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a href="#create" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="file-text"></i> <span class="align-middle">Questions</span>
                </a>
                <ul id="create" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="/admin/question-create">Create</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="/admin/question-list">List</a></li>
                </ul>
            </li>

            


        </ul>
    </div>
</nav>

<div class="main">
    <nav class="navbar navbar-expand navbar-light navbar-bg">
        <a class="sidebar-toggle d-flex">
            <i class="hamburger align-self-center"></i>
        </a>

        

        <div class="navbar-collapse collapse">
            <ul class="navbar-nav navbar-align">
                
                <li class="nav-item dropdown">
                    <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
                        <i class="align-middle" data-feather="settings"></i>
                    </a>

                    <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                        
                            <span class="text-dark"><?php echo e(Auth::guard('admin')->user()->fullName()); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item" href="<?php echo e(route('admin-profile')); ?>"><i class="align-middle me-1"
                                data-feather="user"></i> Profile</a>
                        <a class="dropdown-item" href="<?php echo e(route('admin-change-password')); ?>"><i class="align-middle me-1"
                                data-feather="lock"></i> Change Password</a>
                        <a class="dropdown-item" href=""><i class="align-middle me-1"
                                data-feather="settings"></i> Settings</a>


                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('admin-logout')); ?>"><i class="align-middle me-1"
                                data-feather="log-out"></i> Log out</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <main class="content">
        <?php echo $__env->make('includes.top_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid p-0">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <footer class="footer">
        <div class="container-fluid">
            <div class="row text-muted">
                <div class="col-12 text-center">
                    <p class="mb-0">
                        <a href="index.html" class="text-muted"><strong><?php echo e(env('APP_NAME')); ?> Admin</strong></a> &copy;
                    </p>
                </div>
                
            </div>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main_js'); ?>
    <?php echo $__env->yieldContent('custom_js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/homebrew/var/www/gurufy/resources/views/admin/layouts/main.blade.php ENDPATH**/ ?>