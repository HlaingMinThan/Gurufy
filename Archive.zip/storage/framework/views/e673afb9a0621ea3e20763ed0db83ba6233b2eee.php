<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-3">Profile</h1>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">

                <h5 class="card-title mb-0">Public info</h5>
            </div>
            <div class="card-body">
                <form action="" method="post">
                    
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-8">

                            <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="row">
                               
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" for="">First Name</label>
                                        <input type="text" class="form-control" placeholder="first name" name="first_name" value="<?php echo e(!empty(old('first_name'))?old('first_name'):Auth::guard('admin')->user()->first_name); ?>">
                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger mt-2"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label" for="">Last Name</label>
                                        <input type="text" class="form-control" placeholder="last name" name="last_name" value="<?php echo e(!empty(old('last_name'))?old('last_name'):Auth::guard('admin')->user()->last_name); ?>">
                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger mt-2"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="">Username</label>
                                <input type="text" class="form-control" placeholder="username" value="<?php echo e(Auth::guard('admin')->user()->username); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="">Email Address</label>
                                <input type="text" class="form-control" placeholder="email" value="<?php echo e(Auth::guard('admin')->user()->email); ?>" readonly>
                            </div>
                        </div>
                       
                    </div>

                    <button type="submit" class="btn btn-primary">Save changes</button>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/homebrew/var/www/gurufy/resources/views/admin/profile/index.blade.php ENDPATH**/ ?>